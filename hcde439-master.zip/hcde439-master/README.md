# HCDE 439 Physical Computing Winter 2023

**Instructor:** Nadya Peek

**Teaching assistant:** Jasper Tran O'Leary

This is an example of a student page for HCDE439. Feel free to use this as a template, or create your own!
